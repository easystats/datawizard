#' @export
ci.mle <- ci.glm


#' @export
standard_error.mle <- standard_error.mle2


#' @rdname model_parameters.averaging
#' @export
model_parameters.mle <- model_parameters.glm
