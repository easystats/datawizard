#' @importFrom bayestestR ci
#' @export
bayestestR::ci
