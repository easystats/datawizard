#' @rdname model_parameters.merMod
#' @export
model_parameters.mixed <- model_parameters.glmmTMB
