#' @export
utils::globalVariables(c(
  ".", "p", "where", "x", "y", "variance.ratio", "V1",
  "estimate", "estimate1", "estimate2", "df", "Method",
  "Alternative", "r", "W", "CI", "Fit", "Parameter",
  "95% CI", "95% CI (b)", "b", "Dependent Variable",
  "var.equal", "95% CI (t)", "Row", "..density..",
  "cells", "na", "na_max", "theme_apa"
))
