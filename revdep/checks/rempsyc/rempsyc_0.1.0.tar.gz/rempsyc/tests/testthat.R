library(testthat)
library(rempsyc)

test_check("rempsyc")
