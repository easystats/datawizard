# check_collinearity, ci = NULL

    Code
      print(out)
    Output
      # Check for Multicollinearity
      
      Low Correlation
      
       Term  VIF SE_factor Increased SE
          N 1.00      1.00         1.00
          P 1.00      1.00         1.00
          K 1.00      1.00         1.00

