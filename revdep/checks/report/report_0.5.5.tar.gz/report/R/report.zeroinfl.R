#' @include report.lm.R
#' @export
report.zeroinfl <- report.lm

#' @export
report_effectsize.zeroinfl <- report_effectsize.lm

#' @export
report_table.zeroinfl <- report_table.lm

#' @export
report_statistics.zeroinfl <- report_statistics.lm

#' @export
report_parameters.zeroinfl <- report_parameters.lm

#' @export
report_intercept.zeroinfl <- report_intercept.lm

#' @export
report_model.zeroinfl <- report_model.lm

#' @export
report_info.zeroinfl <- report_info.lm

#' @export
report_text.zeroinfl <- report_text.lm

#' @export
report_performance.zeroinfl <- report_performance.lm
