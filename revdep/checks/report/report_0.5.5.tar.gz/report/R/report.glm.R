#' @include report.lm.R
#' @export
report.glm <- report.lm

#' @export
report_effectsize.glm <- report_effectsize.lm

#' @export
report_table.glm <- report_table.lm

#' @export
report_statistics.glm <- report_statistics.lm

#' @export
report_parameters.glm <- report_parameters.lm

#' @export
report_intercept.glm <- report_intercept.lm

#' @export
report_model.glm <- report_model.lm

#' @export
report_performance.glm <- report_performance.lm

#' @export
report_info.glm <- report_info.lm

#' @export
report_text.glm <- report_text.lm
