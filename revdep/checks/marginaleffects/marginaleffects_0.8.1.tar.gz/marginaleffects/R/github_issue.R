github_issue <- function() {
    msg <- format_msg(
    "Please report this error along with a minimal reproducible example using
    publicly available data on Github:

    https://github.com/vincentarelbundock/marginaleffects/issues
    ")
}

