#' @include get_predict.R
#' @rdname get_predict
#' @export
get_predict.stanreg <- get_predict.brmsfit
