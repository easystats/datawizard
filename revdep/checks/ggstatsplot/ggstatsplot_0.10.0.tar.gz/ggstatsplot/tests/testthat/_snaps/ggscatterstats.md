# grouped_ggscatterstats errors when no grouping is present

    argument 1 is empty

