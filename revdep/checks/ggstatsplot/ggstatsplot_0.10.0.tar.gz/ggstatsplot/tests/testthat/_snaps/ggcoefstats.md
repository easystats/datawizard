# ggcoefstats doesn't work if no estimate column found

    The tidy data frame *must* contain 'estimate' column.

# edge cases

    Elements in `term` column must be unique.

