# default plotting as expected

    argument 1 is empty

