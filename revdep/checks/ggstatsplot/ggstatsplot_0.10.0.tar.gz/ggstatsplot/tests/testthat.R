library(testthat)
library(ggstatsplot)

library(statsExpressions)
library(vdiffr)

test_check("ggstatsplot")
