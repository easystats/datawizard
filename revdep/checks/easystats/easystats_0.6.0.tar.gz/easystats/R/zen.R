#' Welcome to the easyverse
#'
#' @return A reassuring message.
#'
#' @examples
#' easystats_zen()
#'
#' @export
easystats_zen <- function() {
  print("Patience you must have my young padawan.")
}
