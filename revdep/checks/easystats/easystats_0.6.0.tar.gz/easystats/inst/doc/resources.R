## ----message=FALSE, warning=FALSE, include=FALSE------------------------------
options(
  knitr.kable.NA = "",
  digits = 2
)

knitr::opts_chunk$set(
  comment = ">",
  dpi = 450,
  message = FALSE,
  warning = FALSE
)

